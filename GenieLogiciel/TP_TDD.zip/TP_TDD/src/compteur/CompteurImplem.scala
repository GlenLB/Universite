package compteur


/** La classe des compteurs paramétrés par une liste non vide de valeurs maximale pour chaque roue.
 *  La liste ne peut être vide et les valeurs sont forcément positives ou nulles */
class CompteurImpl extends Compteur{
  def init(l:List[Int])= ???
  def courant= ???
  def suivant= ???
  def suivantPossible= ???
  def valPossibles= ???
  def valRestantes= ???
}